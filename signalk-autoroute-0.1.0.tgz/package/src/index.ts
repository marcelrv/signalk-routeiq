/**
 * SignalK Autoroute Plugin - Main Entry Point
 * 
 * A SignalK server plugin that provides offline-first nautical route planning
 * with vessel-aware A* pathfinding on a pre-computed routing graph.
 */

import { ServerAPI } from '@signalk/server-api';
import * as express from 'express';
import * as fs from 'fs';
import * as path from 'path';

import { ApiHandler } from './api.js';
import { RoutingDatabase } from './database.js';
import { RoutingEngine } from './routing.js';
import { DEFAULT_CONFIG, PluginConfig } from './types.js';

// Plugin state
let database: RoutingDatabase | null = null;
let routingEngine: RoutingEngine | null = null;
let apiHandler: ApiHandler | null = null;

/**
 * Plugin constructor factory for SignalK
 */
export function pluginConstructor(app: ServerAPI) {
  let config: PluginConfig = { ...DEFAULT_CONFIG };
  let vesselDimensions = { draft: 0, beam: 4, airDraft: 10 };
  let subscriptionCancelled: (() => void) | null = null;

  const pluginId = 'signalk-autoroute';
  const __filename = new URL(import.meta.url).pathname;
  const __plugindir = path.dirname(path.dirname(__filename)); // dist/.. → plugin root

  return {
    id: pluginId,
    name: 'SignalK Nautical Autoroute',

    /**
     * Start the plugin
     */
    start(options: any, _restart?: () => void) {
      console.log('[autoroute] Starting SignalK Autoroute Plugin...');

      // Merge received configuration with defaults
      config = { ...DEFAULT_CONFIG, ...options };

      // Migrate legacy routingDatabase config to routingDataDir
      if (!config.routingDataDir && (options as any).routingDatabase) {
        config.routingDataDir = path.dirname((options as any).routingDatabase);
        console.log(`[autoroute] Migrated legacy routingDatabase → routingDataDir: ${config.routingDataDir}`);
      }

      // Resolve data directory relative to plugin directory
      if (config.routingDataDir && !path.isAbsolute(config.routingDataDir)) {
        config.routingDataDir = path.resolve(__plugindir, config.routingDataDir);
      }

      // Ensure the data directory exists
      if (config.routingDataDir) {
        try { fs.mkdirSync(config.routingDataDir, { recursive: true }); } catch { /* ignore */ }
      }
      console.log(`[autoroute] Configuration loaded: ${JSON.stringify(config)}`);

      // Create ApiHandler once; Express routes are registered against it on first start.
      // On subsequent starts (config save), only the routing engine is recreated.
      if (!apiHandler) {
        apiHandler = new ApiHandler(config, app);
        console.log('[autoroute] API handler created (awaiting database init)');
      }

      // Re-initialize database/routing engine with (possibly updated) config
      initPluginAsync(app);
    },

    /**
     * Stop the plugin
     */
    async stop() {
      console.log('[autoroute] Stopping SignalK Autoroute Plugin...');

      // Unsubscribe from vessel dimensions
      if (subscriptionCancelled) {
        subscriptionCancelled();
        subscriptionCancelled = null;
      }

      // Close database connection
      if (database) {
        await database.close();
        database = null;
      }

      // Detach engine/db from apiHandler, but keep apiHandler alive
      // so Express routes stay registered across stop/start cycles
      if (apiHandler) {
        (apiHandler as any).db = null;
        (apiHandler as any).routingEngine = null;
      }
      routingEngine = null;

      console.log('[autoroute] Plugin stopped');
    },

    /**
     * Get plugin configuration schema
     */
    schema(_app: any) {
      return {
        type: 'object',
        properties: {
          routingDataDir: {
            type: 'string',
            title: 'Routing Data Directory',
            description: 'Directory containing .sqlite routing graph files',
            default: DEFAULT_CONFIG.routingDataDir,
          },
          safetyMarginDraft: {
            type: 'number',
            title: 'Draft Safety Margin (m)',
            description: 'Under-keel clearance added to design draft',
            default: DEFAULT_CONFIG.safetyMarginDraft,
            minimum: 0,
            multipleOf: 0.1,
          },
          safetyMarginAirDraft: {
            type: 'number',
            title: 'Air Draft Safety Margin (m)',
            description: 'Mast clearance added to design air draft',
            default: DEFAULT_CONFIG.safetyMarginAirDraft,
            minimum: 0,
            multipleOf: 0.1,
          },
          safetyMarginBeam: {
            type: 'number',
            title: 'Beam Safety Margin (m)',
            description: 'Width clearance added to design beam',
            default: DEFAULT_CONFIG.safetyMarginBeam,
            minimum: 0,
            multipleOf: 0.1,
          },
          defaultCoastDistance: {
            type: 'number',
            title: 'Default Min Coast Distance (NM)',
            description: 'Default minimum distance from coastline in nautical miles',
            default: DEFAULT_CONFIG.defaultCoastDistance,
          },
          fairwayMultiplier: {
            type: 'number',
            title: 'Fairway Multiplier',
            description: 'Cost multiplier for fairway edges (lower = preferred)',
            default: DEFAULT_CONFIG.fairwayMultiplier,
          },
          openWaterMultiplier: {
            type: 'number',
            title: 'Open Water Multiplier',
            description: 'Cost multiplier for open water edges (higher = less preferred)',
            default: DEFAULT_CONFIG.openWaterMultiplier,
          },
          wrongWayPenalty: {
            type: 'number',
            title: 'Wrong Way Penalty',
            description: 'Penalty multiplier for traveling against traffic flow',
            default: DEFAULT_CONFIG.wrongWayPenalty,
          },
          routingBBoxMargin: {
            type: 'number',
            title: 'Routing BBox Margin (degrees)',
            description: 'Initial search bounding-box margin around start/end (default 0.1 ≈ 11km)',
            default: DEFAULT_CONFIG.routingBBoxMargin,
          },
          routingBBoxMaxExtent: {
            type: 'number',
            title: 'Routing BBox Max Extent (degrees)',
            description: 'Maximum bounding-box size before falling back to full graph',
            default: DEFAULT_CONFIG.routingBBoxMaxExtent,
          },
          lineOfSightSampleInterval: {
            type: 'number',
            title: 'Line-of-Sight Sample Interval (m)',
            description: 'Spacing between samples when checking line-of-sight for smoothing',
            default: DEFAULT_CONFIG.lineOfSightSampleInterval,
          },
          lineOfSightSearchRadius: {
            type: 'number',
            title: 'Line-of-Sight Search Radius (m)',
            description: 'Radius to search for graph nodes when verifying line-of-sight',
            default: DEFAULT_CONFIG.lineOfSightSearchRadius,
          },
        },
      };
    },

    /**
     * Register routes via Signal K's plugin router (mounted at /plugins/<pluginId>/)
     */
    registerWithRouter(router: express.IRouter) {

      // Serve frontend static files
      const publicPath = path.join(__plugindir, 'public');
      if (fs.existsSync(publicPath)) {
        // Serve index.html at the root explicitly (SK may intercept /plugins/<id>)
        router.get('/', (_req, res) => {
          res.sendFile(path.join(publicPath, 'index.html'));
        });
        router.use(express.static(publicPath));
        console.log(`[autoroute] Frontend served from: ${publicPath}`);
      }

      // Always attach routes — apiHandler was created synchronously in start()
      // so it's guaranteed to exist here. If the DB isn't loaded yet, routes
      // will return 503 Service Unavailable.
      router.use('/router', apiHandler!.getRouter());
      console.log('[autoroute] API routes attached');

      console.log('[autoroute] Router registered, awaiting initialization...');
    },

    /**
     * Register routes under Signal K API path (/signalk/v1/api/router/)
     */
    signalKApiRoutes(router: express.IRouter) {
      if (apiHandler) {
      router.use('/router', apiHandler!.getRouter());
      }
      return router;
    },
  };

  /**
   * Initialize plugin components asynchronously
   */
  async function initPluginAsync(app: ServerAPI) {
    try {
      if (!config.routingDataDir) {
        throw new Error('routingDataDir is not configured');
      }
      database = new RoutingDatabase(config.routingDataDir);
      await database.init();
      await database.loadGraph();
      const stats = await database.getStats();
      console.log(`[autoroute] Database loaded: ${stats.nodes} nodes, ${stats.edges} edges, ${stats.pois} POIs`);

      routingEngine = new RoutingEngine(database, config);
      apiHandler!.setComponents(database, routingEngine);
      console.log('[autoroute] API handler ready');

      // Fetch initial vessel dimensions synchronously (subscription may not fire for static values)
      await fetchInitialVesselDimensions(app);

      // Subscribe to future vessel dimension changes
      await subscribeToVesselDimensions(app);
      console.log('[autoroute] Plugin started successfully');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      console.error(`[autoroute] Failed to initialize: ${message}`);
    }
  }

  /**
   * Fetch initial vessel dimensions from Signal K path API
   */
  async function fetchInitialVesselDimensions(app: ServerAPI) {
    try {
      const appAny = app as any;
      let draft: number | undefined;
      let beam: number | undefined;
      let airDraft: number | undefined;

      // Try getSelfPath (preferred)
      if (typeof appAny.getSelfPath === 'function') {
        const draftPath = appAny.getSelfPath('design.draft');
        draft = extractNumberValue(draftPath);
        const beamPath = appAny.getSelfPath('design.beam');
        beam = extractNumberValue(beamPath);
        const airDraftPath = appAny.getSelfPath('design.airHeight');
        airDraft = extractNumberValue(airDraftPath);
      } else if (typeof appAny.getPath === 'function') {
        // Fallback: full path
        const draftPath = appAny.getPath('vessels.self.design.draft');
        draft = extractNumberValue(draftPath);
        const beamPath = appAny.getPath('vessels.self.design.beam');
        beam = extractNumberValue(beamPath);
        const airDraftPath = appAny.getPath('vessels.self.design.airHeight');
        airDraft = extractNumberValue(airDraftPath);
      }

      if (draft !== undefined || beam !== undefined || airDraft !== undefined) {
        const newDimensions: Partial<typeof vesselDimensions> = {};
        if (draft !== undefined) newDimensions.draft = draft;
        if (beam !== undefined) newDimensions.beam = beam;
        if (airDraft !== undefined) newDimensions.airDraft = airDraft;
        vesselDimensions = { ...vesselDimensions, ...newDimensions };
        routingEngine!.setVesselDimensions(vesselDimensions);
        console.log(`[autoroute] Vessel dimensions (from path API): ${JSON.stringify(vesselDimensions)}`);
      }
    } catch (error) {
      console.warn('[autoroute] Failed to fetch initial vessel dimensions:', error);
    }
  }

  /**
   * Extract a numeric value from a Signal K path value (handles nested formats)
   */
  function extractNumberValue(v: any): number | undefined {
    if (v === undefined || v === null) return undefined;
    if (typeof v === 'number') return v;
    if (typeof v.value === 'number') return v.value;
    if (v.value && typeof v.value.maximum === 'number') return v.value.maximum;
    if (typeof v.maximum === 'number') return v.maximum;
    if (typeof v.current === 'number') return v.current;
    return undefined;
  }

  /**
   * Subscribe to vessel dimensions from Signal K delta tree
   */
  async function subscribeToVesselDimensions(app: ServerAPI) {
    try {
      const appAny = app as any;
      if (typeof appAny.subscriptionmanager?.subscribe === 'function') {
        const command = {
          context: 'vessels.self',
          subscribe: [
            { path: 'design.draft', period: 1000, format: 'delta' },
            { path: 'design.beam', period: 1000, format: 'delta' },
            { path: 'design.airHeight', period: 1000, format: 'delta' },
          ],
        };
        const unsubscribeFns: (() => void)[] = [];
        appAny.subscriptionmanager.subscribe(
          command,
          unsubscribeFns,     // collect unsubscribe callbacks
          () => {},           // errorCallback
          (update: any) => {  // callback
            handleVesselUpdate(update);
          },
        );
        subscriptionCancelled = () => {
          unsubscribeFns.forEach(fn => fn());
        };
      } else if (typeof appAny.subscribe === 'function') {
        // fallback: older API
        const subscription = { context: 'vessels.self', subscribe: [
          { path: 'design.draft' },
          { path: 'design.beam' },
          { path: 'design.airHeight' },
        ]};
        subscriptionCancelled = appAny.subscribe(subscription, (update: any) => {
          handleVesselUpdate(update);
        });
      }
    } catch (error) {
      console.warn('[autoroute] Failed to subscribe to vessel dimensions:', error);
    }
  }

  /**
   * Handle vessel dimension updates from Signal K
   */
  function handleVesselUpdate(delta: any) {
    if (!routingEngine) return;
    const newDimensions: Partial<typeof vesselDimensions> = {};

    // Extract values from delta updates array
    const updates = delta.updates || [];
    for (const update of updates) {
      const values = update.values || [];
      for (const entry of values) {
        const p = entry.path || '';
        const value = entry.value;
        const numValue = typeof value === 'number' ? value 
          : typeof value?.value === 'number' ? value.value
          : value?.value?.maximum ?? value?.maximum ?? value?.current ?? value;
        if (typeof numValue === 'number') {
          if (p === 'design.draft' || p === 'design.draft.value') newDimensions.draft = numValue;
          if (p === 'design.beam' || p === 'design.beam.value') newDimensions.beam = numValue;
          if (p === 'design.airHeight' || p === 'design.airHeight.value') newDimensions.airDraft = numValue;
        }
      }
    }

    // Also try full-tree format (from app.getPath or similar)
    if (delta.vessels) {
      const vessels = delta.vessels || {};
      for (const vessel of Object.values(vessels) as any[]) {
        const design = vessel.design || {};
        if (design.draft !== undefined && typeof design.draft !== 'string') {
          const extracted = extractNumberValue(design.draft);
          if (extracted !== undefined) newDimensions.draft = extracted;
        }
        if (design.beam !== undefined && typeof design.beam !== 'string') {
          const extracted = extractNumberValue(design.beam);
          if (extracted !== undefined) newDimensions.beam = extracted;
        }
        if (design.airHeight !== undefined && typeof design.airHeight !== 'string') {
          const extracted = extractNumberValue(design.airHeight);
          if (extracted !== undefined) newDimensions.airDraft = extracted;
        }
      }
    }

    // Update vessel dimensions if we got any values
    if (Object.keys(newDimensions).length > 0) {
      vesselDimensions = { ...vesselDimensions, ...newDimensions };
      routingEngine.setVesselDimensions(vesselDimensions);
      console.log(`[autoroute] Vessel dimensions updated: ${JSON.stringify(vesselDimensions)}`);
    }
  }
}

// Default export for Signal K server's ESM loader (returns module.default)
export { pluginConstructor as default };
